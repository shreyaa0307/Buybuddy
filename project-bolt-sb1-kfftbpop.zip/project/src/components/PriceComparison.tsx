import React from 'react';
import { ExternalLink, Award, TrendingDown } from 'lucide-react';

interface PriceOption {
  retailer: string;
  price: number;
  shipping: number;
  rating: number;
  inStock: boolean;
  logo: string;
}

interface PriceComparisonProps {
  product: string;
  options: PriceOption[];
}

export const PriceComparison: React.FC<PriceComparisonProps> = ({ product, options }) => {
  const sortedOptions = [...options].sort((a, b) => (a.price + a.shipping) - (b.price + b.shipping));
  const bestDeal = sortedOptions[0];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900">Price Comparison</h3>
        <div className="flex items-center text-green-600">
          <TrendingDown className="w-5 h-5 mr-1" />
          <span className="text-sm font-medium">Best deals first</span>
        </div>
      </div>
      
      <div className="space-y-4">
        {sortedOptions.map((option, index) => (
          <div
            key={option.retailer}
            className={`border rounded-lg p-4 transition-all duration-200 ${
              option.retailer === bestDeal.retailer
                ? 'border-green-500 bg-green-50 ring-2 ring-green-200'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                  <span className="text-xl font-bold text-gray-600">
                    {option.retailer.charAt(0)}
                  </span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">{option.retailer}</h4>
                  <div className="flex items-center space-x-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <div
                          key={i}
                          className={`w-3 h-3 rounded-full ${
                            i < Math.floor(option.rating) ? 'bg-yellow-400' : 'bg-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">({option.rating})</span>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="flex items-center space-x-2">
                  <div>
                    <div className="text-2xl font-bold text-gray-900">
                      ${option.price.toFixed(2)}
                    </div>
                    {option.shipping > 0 && (
                      <div className="text-sm text-gray-600">
                        + ${option.shipping.toFixed(2)} shipping
                      </div>
                    )}
                  </div>
                  {option.retailer === bestDeal.retailer && (
                    <Award className="w-6 h-6 text-green-500" />
                  )}
                </div>
                
                <div className="flex items-center space-x-2 mt-2">
                  <span className={`text-sm px-2 py-1 rounded ${
                    option.inStock 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {option.inStock ? 'In Stock' : 'Out of Stock'}
                  </span>
                  <button className="text-blue-500 hover:text-blue-600 transition-colors">
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
            
            {option.retailer === bestDeal.retailer && (
              <div className="mt-3 p-3 bg-green-100 rounded-md">
                <div className="flex items-center space-x-2">
                  <Award className="w-5 h-5 text-green-600" />
                  <span className="text-sm font-medium text-green-800">
                    Best Deal - Save up to ${(sortedOptions[sortedOptions.length - 1].price - option.price).toFixed(2)}
                  </span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};