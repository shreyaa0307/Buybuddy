import React from 'react';
import { Gift, Clock, Zap, Target } from 'lucide-react';

interface Offer {
  id: string;
  title: string;
  description: string;
  discount: string;
  category: string;
  expiresIn: string;
  type: 'flash' | 'personalized' | 'seasonal' | 'loyalty';
}

export const PersonalizedOffers: React.FC = () => {
  const offers: Offer[] = [
    {
      id: '1',
      title: 'Your Weekly Groceries',
      description: 'Based on your shopping history, save on essentials',
      discount: '25% OFF',
      category: 'Groceries',
      expiresIn: '2 days',
      type: 'personalized'
    },
    {
      id: '2',
      title: 'Flash Sale: Electronics',
      description: 'Limited time offer on tech gadgets',
      discount: '40% OFF',
      category: 'Electronics',
      expiresIn: '4 hours',
      type: 'flash'
    },
    {
      id: '3',
      title: 'Seasonal Special',
      description: 'Winter essentials at unbeatable prices',
      discount: '30% OFF',
      category: 'Clothing',
      expiresIn: '1 week',
      type: 'seasonal'
    },
    {
      id: '4',
      title: 'Loyalty Reward',
      description: 'Exclusive offer for valued customers',
      discount: '50% OFF',
      category: 'Home & Garden',
      expiresIn: '3 days',
      type: 'loyalty'
    }
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'flash': return <Zap className="w-5 h-5" />;
      case 'personalized': return <Target className="w-5 h-5" />;
      case 'seasonal': return <Gift className="w-5 h-5" />;
      case 'loyalty': return <Gift className="w-5 h-5" />;
      default: return <Gift className="w-5 h-5" />;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'flash': return 'bg-red-500';
      case 'personalized': return 'bg-blue-500';
      case 'seasonal': return 'bg-green-500';
      case 'loyalty': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Personalized Offers</h2>
        <div className="flex items-center text-sm text-gray-600">
          <Clock className="w-4 h-4 mr-1" />
          Updated hourly
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {offers.map((offer) => (
          <div
            key={offer.id}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className={`p-2 rounded-lg text-white ${getColor(offer.type)}`}>
                  {getIcon(offer.type)}
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-red-500">{offer.discount}</div>
                  <div className="text-sm text-gray-600">Expires in {offer.expiresIn}</div>
                </div>
              </div>
              
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{offer.title}</h3>
              <p className="text-gray-600 text-sm mb-4">{offer.description}</p>
              
              <div className="flex items-center justify-between">
                <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                  {offer.category}
                </span>
                <button className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors">
                  Claim Offer
                </button>
              </div>
            </div>
            
            {offer.type === 'flash' && (
              <div className="bg-red-50 border-t border-red-200 px-6 py-2">
                <div className="flex items-center text-red-600 text-sm">
                  <Zap className="w-4 h-4 mr-1" />
                  Flash Sale - Limited quantities available!
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};