import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2 } from 'lucide-react';

interface VoiceAssistantProps {
  isActive: boolean;
  onToggle: () => void;
  onVoiceCommand: (command: string) => void;
}

export const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ isActive, onToggle, onVoiceCommand }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');

  useEffect(() => {
    if (isActive) {
      startListening();
    } else {
      stopListening();
    }
  }, [isActive]);

  const startListening = () => {
    setIsListening(true);
    // Simulate voice recognition
    setTimeout(() => {
      const sampleCommands = [
        "Find me organic groceries under $50",
        "Show me deals on electronics",
        "Compare prices for iPhone 15",
        "Add milk and bread to my cart"
      ];
      const randomCommand = sampleCommands[Math.floor(Math.random() * sampleCommands.length)];
      setTranscript(randomCommand);
      onVoiceCommand(randomCommand);
      setIsListening(false);
    }, 3000);
  };

  const stopListening = () => {
    setIsListening(false);
    setTranscript('');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className={`mb-4 transition-all duration-300 ${isActive ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
        {transcript && (
          <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200 max-w-xs">
            <p className="text-sm text-gray-700">"{transcript}"</p>
          </div>
        )}
        {isListening && (
          <div className="bg-blue-500 text-white p-3 rounded-lg shadow-lg">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
              <div className="w-2 h-2 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
              <div className="w-2 h-2 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
              <span className="text-sm">Listening...</span>
            </div>
          </div>
        )}
      </div>
      
      <button
        onClick={onToggle}
        className={`w-16 h-16 rounded-full shadow-lg transition-all duration-300 flex items-center justify-center ${
          isActive 
            ? 'bg-red-500 hover:bg-red-600 scale-110' 
            : 'bg-blue-500 hover:bg-blue-600 hover:scale-105'
        }`}
      >
        {isActive ? (
          <MicOff className="w-8 h-8 text-white" />
        ) : (
          <Mic className="w-8 h-8 text-white" />
        )}
      </button>
    </div>
  );
};