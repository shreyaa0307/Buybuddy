import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { VoiceAssistant } from './components/VoiceAssistant';
import { ChatAssistant } from './components/ChatAssistant';
import { ProductCard } from './components/ProductCard';
import { PriceComparison } from './components/PriceComparison';
import { PersonalizedOffers } from './components/PersonalizedOffers';
import { ShoppingCartComponent } from './components/ShoppingCart';
import { Sparkles, Zap, Target, TrendingUp, Brain, Mic } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  badge?: string;
  savings?: number;
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'products' | 'comparison' | 'offers'>('home');
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [currentDemo, setCurrentDemo] = useState(0);

  const products: Product[] = [
    {
      id: '1',
      name: 'Organic Avocados (6 pack)',
      price: 8.99,
      originalPrice: 12.99,
      rating: 4.5,
      reviews: 234,
      image: 'https://images.pexels.com/photos/1656663/pexels-photo-1656663.jpeg?auto=compress&cs=tinysrgb&w=400',
      badge: 'AI Pick',
      savings: 4.00
    },
    {
      id: '2',
      name: 'Smart Wireless Earbuds',
      price: 79.99,
      originalPrice: 129.99,
      rating: 4.8,
      reviews: 892,
      image: 'https://images.pexels.com/photos/3780681/pexels-photo-3780681.jpeg?auto=compress&cs=tinysrgb&w=400',
      badge: 'Best Deal',
      savings: 50.00
    },
    {
      id: '3',
      name: 'Organic Ground Coffee',
      price: 14.99,
      originalPrice: 19.99,
      rating: 4.6,
      reviews: 456,
      image: 'https://images.pexels.com/photos/1339813/pexels-photo-1339813.jpeg?auto=compress&cs=tinysrgb&w=400',
      badge: 'Popular',
      savings: 5.00
    },
    {
      id: '4',
      name: 'Yoga Mat Premium',
      price: 45.99,
      originalPrice: 65.99,
      rating: 4.7,
      reviews: 189,
      image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=400',
      badge: 'Trending',
      savings: 20.00
    }
  ];

  const priceComparisonData = {
    product: "Smart Wireless Earbuds",
    options: [
      { retailer: "Walmart", price: 79.99, shipping: 0, rating: 4.8, inStock: true, logo: "W" },
      { retailer: "Amazon", price: 84.99, shipping: 0, rating: 4.6, inStock: true, logo: "A" },
      { retailer: "Best Buy", price: 89.99, shipping: 5.99, rating: 4.7, inStock: true, logo: "B" },
      { retailer: "Target", price: 92.99, shipping: 0, rating: 4.5, inStock: false, logo: "T" }
    ]
  };

  const demoSteps = [
    { title: "Welcome to ShopSmart AI", subtitle: "Your intelligent shopping companion" },
    { title: "Voice-Activated Shopping", subtitle: "Just speak to find what you need" },
    { title: "Smart Recommendations", subtitle: "AI-powered product suggestions" },
    { title: "Price Comparison", subtitle: "Find the best deals automatically" },
    { title: "Personalized Offers", subtitle: "Tailored deals just for you" }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDemo((prev) => (prev + 1) % demoSteps.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const handleVoiceCommand = (command: string) => {
    if (command.toLowerCase().includes('price') || command.toLowerCase().includes('compare')) {
      setCurrentView('comparison');
    } else if (command.toLowerCase().includes('deals') || command.toLowerCase().includes('offers')) {
      setCurrentView('offers');
    } else {
      setCurrentView('products');
    }
  };

  const handleAddToCart = (product: Product) => {
    const existingItem = cartItems.find(item => item.id === product.id);
    if (existingItem) {
      setCartItems(cartItems.map(item =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCartItems([...cartItems, {
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: 1,
        image: product.image
      }]);
    }
  };

  const handleUpdateQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      setCartItems(cartItems.filter(item => item.id !== id));
    } else {
      setCartItems(cartItems.map(item =>
        item.id === id ? { ...item, quantity } : item
      ));
    }
  };

  const handleRemoveItem = (id: string) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };

  const renderHomeView = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex items-center justify-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <Brain className="w-10 h-10 text-white" />
              </div>
            </div>
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              {demoSteps[currentDemo].title}
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              {demoSteps[currentDemo].subtitle}
            </p>
            <div className="flex items-center justify-center space-x-4 mb-12">
              <button
                onClick={() => setIsVoiceActive(!isVoiceActive)}
                className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-8 py-4 rounded-full font-semibold hover:shadow-lg transition-all duration-300 flex items-center space-x-2"
              >
                <Mic className="w-5 h-5" />
                <span>Try Voice Shopping</span>
              </button>
              <button
                onClick={() => setCurrentView('products')}
                className="bg-white text-gray-900 px-8 py-4 rounded-full font-semibold border border-gray-300 hover:bg-gray-50 transition-all duration-300"
              >
                Browse Products
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="text-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-6 h-6 text-blue-500" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">AI Recommendations</h3>
            <p className="text-gray-600 text-sm">Smart suggestions based on your preferences</p>
          </div>
          
          <div className="text-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-6 h-6 text-green-500" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Price Comparison</h3>
            <p className="text-gray-600 text-sm">Find the best deals across retailers</p>
          </div>
          
          <div className="text-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Target className="w-6 h-6 text-purple-500" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Personalized Offers</h3>
            <p className="text-gray-600 text-sm">Exclusive deals tailored to you</p>
          </div>
          
          <div className="text-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-orange-500" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Voice Shopping</h3>
            <p className="text-gray-600 text-sm">Shop hands-free with voice commands</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => setCurrentView('products')}
              className="bg-blue-50 hover:bg-blue-100 text-blue-700 p-4 rounded-lg transition-colors"
            >
              <Sparkles className="w-6 h-6 mx-auto mb-2" />
              <span className="block font-semibold">Smart Recommendations</span>
            </button>
            <button
              onClick={() => setCurrentView('comparison')}
              className="bg-green-50 hover:bg-green-100 text-green-700 p-4 rounded-lg transition-colors"
            >
              <TrendingUp className="w-6 h-6 mx-auto mb-2" />
              <span className="block font-semibold">Compare Prices</span>
            </button>
            <button
              onClick={() => setCurrentView('offers')}
              className="bg-purple-50 hover:bg-purple-100 text-purple-700 p-4 rounded-lg transition-colors"
            >
              <Target className="w-6 h-6 mx-auto mb-2" />
              <span className="block font-semibold">View Offers</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderProductsView = () => (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">AI Recommendations</h1>
        <button
          onClick={() => setCurrentView('home')}
          className="text-blue-500 hover:text-blue-600 transition-colors"
        >
          ← Back to Home
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onAddToCart={handleAddToCart}
          />
        ))}
      </div>
    </div>
  );

  const renderComparisonView = () => (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Price Comparison</h1>
        <button
          onClick={() => setCurrentView('home')}
          className="text-blue-500 hover:text-blue-600 transition-colors"
        >
          ← Back to Home
        </button>
      </div>
      
      <PriceComparison
        product={priceComparisonData.product}
        options={priceComparisonData.options}
      />
    </div>
  );

  const renderOffersView = () => (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Personalized Offers</h1>
        <button
          onClick={() => setCurrentView('home')}
          className="text-blue-500 hover:text-blue-600 transition-colors"
        >
          ← Back to Home
        </button>
      </div>
      
      <PersonalizedOffers />
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        cartItemCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
        onCartClick={() => setIsCartOpen(true)}
        onChatClick={() => setIsChatOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {currentView === 'home' && renderHomeView()}
      {currentView === 'products' && renderProductsView()}
      {currentView === 'comparison' && renderComparisonView()}
      {currentView === 'offers' && renderOffersView()}

      <VoiceAssistant
        isActive={isVoiceActive}
        onToggle={() => setIsVoiceActive(!isVoiceActive)}
        onVoiceCommand={handleVoiceCommand}
      />

      <ChatAssistant
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
      />

      <ShoppingCartComponent
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
      />
    </div>
  );
}

export default App;